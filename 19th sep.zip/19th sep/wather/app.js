const API_KEY = "YOUR_OPENWEATHER_API_KEY"; // Replace with your API key

document.getElementById("searchBtn").addEventListener("click", () => {
  const city = document.getElementById("cityInput").value;
  if (city) {
    getWeather(city);
  }
});

async function getWeather(city) {
  try {
    const currentRes = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`);
    const currentData = await currentRes.json();

    if (currentData.cod !== 200) throw new Error(currentData.message);

    document.getElementById("currentWeather").classList.remove("d-none");
    document.getElementById("cityName").textContent = currentData.name;
    document.getElementById("temp").textContent = currentData.main.temp;
    document.getElementById("humidity").textContent = currentData.main.humidity;
    document.getElementById("wind").textContent = currentData.wind.speed;
    document.getElementById("description").textContent = currentData.weather[0].description;
    document.getElementById("weatherIcon").src = `https://openweathermap.org/img/wn/${currentData.weather[0].icon}.png`;

    getForecast(city);
  } catch (err) {
    alert("Error: " + err.message);
  }
}

async function getForecast(city) {
  const forecastContainer = document.getElementById("forecast");
  forecastContainer.innerHTML = ""; // Clear previous cards

  const res = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}&units=metric`);
  const data = await res.json();

  const daily = {};

  for (let entry of data.list) {
    const date = entry.dt_txt.split(" ")[0];
    if (!daily[date] && entry.dt_txt.includes("12:00:00")) {
      daily[date] = entry;
    }
  }

  Object.values(daily).slice(0, 5).forEach(day => {
    const card = `
      <div class="col-md-2 col-6">
        <div class="bg-white p-3 rounded shadow text-center">
          <h5>${new Date(day.dt_txt).toLocaleDateString()}</h5>
          <img src="https://openweathermap.org/img/wn/${day.weather[0].icon}.png" />
          <p class="mb-1">${day.main.temp.toFixed(1)}°C</p>
          <small>${day.weather[0].main}</small>
        </div>
      </div>
    `;
    forecastContainer.innerHTML += card;
  });
}
