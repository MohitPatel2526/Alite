console.log(document.body.firstChild);
console.log(document.body.astChild );   
console.log(document.body.childNodes);