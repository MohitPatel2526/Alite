alert("Enter the value of a!");
let a = prompt("Enter  a here", "578")
a= Number.parseInt(a)
alert("You entered a of type" + typeof a);