// //Functions in js
// function avg(a,b){
//     return (a+b)/2;
// }     

// c1 = avg(4,6);
// c2 = avg(14,16);
// console.log(c1,c2);     

let a = 1;
let b = 2;
let c = 3;
console.log(a,b,c);
a = b = c = 4;
console.log(a,b,c);     
// a = a + 1;
a += 1;
console.log(a);

console.log(a==b);
console.log(a!=b);
console.log(a>=b);
console.log(a<=b);
console.log(a>b);
console.log(a<b);   