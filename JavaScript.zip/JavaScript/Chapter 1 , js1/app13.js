let name = "mohit";
console.log(name.length);
let frend = "ram";
console.log(frend.length);
console.log(name.indexOf("h"));
//console.log(name.indexOf("h"));
//console.log(name.indexOf("z"));
