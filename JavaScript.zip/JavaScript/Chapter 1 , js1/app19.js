let arr = [45, 23, 21]

//console .log(arr0
arr.map((value) => {
    console.log(value);
})
console.log(arr);
