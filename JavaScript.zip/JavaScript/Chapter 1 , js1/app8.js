//Logical operater
let age = prompt("what is your age?");
if (age<10 && age<20){

    console.log("Your age lies between 10 and 20")
    }
    else{
        console.log("Your age is not between 10 and 20")

    }