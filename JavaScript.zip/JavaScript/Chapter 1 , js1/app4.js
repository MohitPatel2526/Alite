let a= null;

let b = 345;
let c = true;
let d= BigInt("567") + BigInt("3");
let e = "mohit";
let f = Symbol("i am a nice Symbol");
let g = undefined;
console.log(a,b,c,d,e,f,g);
console.log(typeof a);

// Object in JS
const item = {
    "Harry" : true,
    "Shubh" : false,
    "Lovish": 67,
    "Rohan" : undefined
}
console.log(item["Harry"])
console.log(typeof item);
// Non Primitive Data Type - Objects in JS

