// Operators in js
console.log("Operaters in js");
let a = 45;
let b = 4;
console.log("a + b = ", a+b)
console.log("a - b = ", a-b)
console.log("a/b =" , a/b)
console.log("a ** b =" , a**b)
console.log("a % b =", a%b)
console.log("a ** b =", a**b)
console.log("++a = ", ++a);
console.log("a++ = ", a++)
console.log("--a =",--a)
console.log("a-- =", a--)
console.log("a-- = ", a--);

// comparison operators
let comp1 = 4
let comp2 = 5;
console.log("comp1 == comp2 is ", comp1 == comp2)
console.log("comp1 == comp2 is" , comp1 != comp2)

//Logical operater
let x =5;
let y = 6;
console.log(x<y || x==5);
console.log(x>y || x==5);
