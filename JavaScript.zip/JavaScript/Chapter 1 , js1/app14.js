// let name = "mohit";
// let friend = "ram";
// console.log(name.concat(" is a friend of ", friend));


let frend = "Naman";
console.log(name.concat(" is a friend of ", frend, " ok "));
let frend2 = "  Harry   "   
console.log(frend2);
console.log(frend2.trim());
