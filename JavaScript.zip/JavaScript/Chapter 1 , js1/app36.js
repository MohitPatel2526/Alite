// change the card title to red color
let ctitle = document.getElementById("firstcardtitle");
ctitle.style.color = "red";

let ctitles= document.querySelectorAll(".card-title");
ctitlel[0].style.color = "blue";
ctitlel[1].style.color = "green";       
ctitlel[2].style.color = "yellow";
console.log(ctitles);   

document.querySelector(".this").style.color = "purple";
docomeent.querySelector(".this").style.background = "black";
document.querySelector(".this").style.fontSize = "30px";