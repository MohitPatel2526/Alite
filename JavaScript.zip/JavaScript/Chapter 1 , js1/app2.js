console.log("this repal contains code for the ultimate js Course video no2");
let a= 67; // a contains 67 
a = "Mohit"
console.log(a);
