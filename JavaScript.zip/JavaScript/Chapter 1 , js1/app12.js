let marks = {
    mohit:  90,
    ram: 78,
    shyam: 88,
    monika: 67
}

for(let i=0;i<Object.keys( marks).length;i++){
    console.log("The marks of "+ Object.keys(marks)[i] + " are " + marks[Object.keys(marks)[i]] + Object.keys(marks)[i] + " are " + marks[Object.keys(marks)[i]] );

}
