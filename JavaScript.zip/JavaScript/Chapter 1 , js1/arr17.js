let num = [1,2,3,34,4,5];   
let b = num.toString(); //b is now a string
console.log(b); 
console.log(num);
