// // chapter 5 pratice set

// //create nam arry of number and take input from the user to add number to the array.

// let arr = [1 ,2 ,3 ,4 ,5, 6, 7, 8, 9];
// let a =prompt("Enter a number");
// a= Number.parseInt
// (a);
// arr.push(a);
// console.log(arr);

 

let arr = [1,2,3,4,5,6,7,8,9];let n = arr.reduce((x1,x2) => {
    return x1* x2;
}   )
console.log(n);
console.log(arr);