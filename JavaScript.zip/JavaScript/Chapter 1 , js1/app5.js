// Chapter 1 - Q1 Create a variable of type string and try to add a number to it.

let a = "Mohit";
let b =  3;
console.log(a+ b)

// Chapter 1 -Q2 Use type of operator to find the datatype of the string in last question.

console.log(typeof (a+b))
//  Q3 create a const object in javascript can you change it to hold a number latter ?

const a1 = {
    name: "mohit",
    section :  1,
    isPrincipal: false
}

// Q4 Try to add a new key to the const object in problem 3 were you able to do it?

a1['friend'] = "Shubham"
a1['name'] = "Lovish"
console.log(a1)
console.log(a1)
console.log(a1)
console.log(a1)
console.log(a1)
//Q 5 write a js program to create a word- meaning dicttonary of 5 words
const dict = {
     appreciate: "recognize the full worth of.",
     ataraxia: "a state of feedom from emotional disturvance and anxiety",
     yakka : "work, especially hard work."
}
console.log(dict.yakka);