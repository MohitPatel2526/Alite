let num = [ 324,424,424,42,43,34,6687];
num.sort();
console.log(num);