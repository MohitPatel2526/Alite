console.log("Hello World");
let a = 10;
let b = 20;
console.log(a + b); //Addition