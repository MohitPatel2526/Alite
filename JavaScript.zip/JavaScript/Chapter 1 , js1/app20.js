// let arr = [45, 23, 21]

// //console .log(arr0
// arr.map((value) => {
//     console.log(value);
// })
// console.log(arr);


// 2nd.
let arr2 = [45, 23, 21 ,0, -9, 3, 67, 89, 100, 200, 300] 
    let a2 = arr2.filter((a) => {
        return a>10;
    })
    console.log(a2);

    
    //Aeduce function
