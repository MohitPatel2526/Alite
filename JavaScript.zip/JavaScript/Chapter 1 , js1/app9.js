//for(let i =0;i<5;i++){
  //  console.log(i);


//   Q.2
    // for(let i =0; i< 500;i++){
    //     console.log(i);
    // }


    let j = 0;
    while(j<5){
        console.log(j);
        console.log(j);
        j++;
    }