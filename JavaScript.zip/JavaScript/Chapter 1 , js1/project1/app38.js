// document.getElementsByTagNameNS("nav") [0].firstElementChild.style.color = "red";

// document.getElementsByTagNameNS("nav") [0].firstElementChild.style.color    = "green";

// document.getElementsByTagName("nav") [0].firstElementChild.style.color = "gray";

// document.getElementsByTagNam