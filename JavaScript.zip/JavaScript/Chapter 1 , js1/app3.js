console.log("javaScript");
var a= 45;
var b= "Harry";
var c = nul
var d = undefined