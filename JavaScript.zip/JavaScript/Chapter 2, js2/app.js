
// 1. Assignment Operators //
let x = 10; // Assigns the value 10 to the variable x
let y = 5;  // Assigns the value 5 to the variable y   
let z = x + y; // Assigns the sum of x and y to the variable z
console.log("x + y = ",x + y); // Outputs: x + y = 15


// 2. Arithmetic Operators //
let a = 20;
let b = 4;
console.log("a + b = ", a + b); // Addition: Outputs: a + b = 24
console.log("a - b = ", a - b); // Subtraction: Outputs: a - b = 16
console.log("a * b = ", a * b); // Multiplication: Outputs: a * b = 80
console.log("a / b = ", a / b); // Division: Outputs: a / b = 5
console.log("a % b = ", a % b); // Modulus: Outputs: a % b = 0
console.log("a ** b = ", a ** b); // Exponentiation: Outputs: a ** b = 1600000000       
console.log("++a = ", ++a); // Increment: Outputs: ++a = 21
console.log("--b = ", --b); // Decrement: Outputs: --b = 3  
console.log("a++ = ", a++); // Post-increment: Outputs: a++ = 21
console.log("b-- = ", b--); // Post-decrement: Outputs: b-- = 3
console.log("New value of a after a++: ", a); // Outputs: New value of a after a++: 22
console.log("New value of b after b--: ", b); // Outputs: New value of b after b--: 2       

// 3. Comparison Operators ja pr hme comparsion krna padta h bha comprison operarors use krnte h //
let m = 15;
let n = 10;
console.log("m == n: ", m == n);


//logical operators //  
let p = true;
let q = false;

console.log("p && q: ", p && q); // Logical AND: Outputs: p && q: false
console.log("p || q: ", p || q); // Logical OR: Outputs: p || q: true
console.log("!p: ", !p); // Logical NOT: Outputs: !p: false     
console.log("!q: ", !q); // Logical NOT: Outputs: !q: true

/*multiple line comment
 1. Assignment Operators
 2. Arithmetic Operators            
    3. Comparison Operators 

. Logical Operators            
    5. String Operators
    6. Conditional (Ternary) Operator
     */